import React from 'react';
import Wall from './components/Wall/Wall';

function App() {
	return (
		<div className="App">
			<Wall />
		</div>
	);
}

export default App;
