import {
	POST_EDIT,
	POST_HIDE,
	POST_SHOW
} from '../actions';

import { combineReducers } from 'redux';
import { postsReducer } from './posts';
import { editedReducer } from './edited';

const appReducer = combineReducers({
	posts: postsReducer,
	edited: editedReducer,
})

export const rootReducer = (state, action) => {
	switch (action.type) {
		case POST_EDIT:
			return reduceEdit(state, action);
		case POST_HIDE:
			return reduceToggleVisibility(state, action);
		case POST_SHOW:
			return reduceToggleVisibility(state, action);
		default:
			return appReducer(state, action);
	}
};

const reduceEdit = (state, action) => {
	const { posts } = state.posts;

	const item = posts.find(o => o.id === action.payload.id);
	if (item === undefined) {
		return state;
	}
	console.log(item);
	return {
		...state,
		edited: { ...state.edited, loading:false, error:null}
	}
};

// const reduceSubmit = (state, action) => {
// 	const { edited, posts } = state;
// 	const parsed = edited.tags?.map(o => o.replace('#', '')).filter(o => o.trim() !== '') || [];
// 	const tags = parsed.length !== 0 ? parsed : null;

// 	const post = {
// 		...edited,
// 		id: edited.id || Date.now(),
// 		created: edited.created || Date.now(),
// 		tags,
// 		photo: edited.photo?.url ? { alt: '', ...edited.photo } : null
// 	};
// 	if (edited?.id === 0) {
// 		return {
// 			...state,
// 			posts: [{ ...post }, ...posts],
// 		}
// 	}
// 	return {
// 		...state,
// 		posts: posts.map((o) => {
// 			if (o.id !== post.id) {
// 				return o;
// 			}
// 			return { ...post };
// 		}),
// 	}
// };

const reduceToggleVisibility = (state, action) => {
	const { posts } = state;
	const { payload: { id } } = action;

	return {
		...state,
		posts: posts.map(o => {
			if (o.id !== id) {
				return o;
			}
			const hidden = !o.hidden;
			return { ...o, hidden };
		})
	};
}






// export const initialState = {
// 	posts: {
// 		items: [],
// 		loading: false,
// 		error: null,
// 	},
// 	edited: {
// 		item: empty,
// 		loading: false,
// 		error: null,
// 	}
// };

// export const reducer = (state = initialState, action) => {
// 	switch (action.type) {
// 		case POST_EDIT_SUBMIT:
// 			return reduceSubmit(state, action);
// 		case POST_HIDE:
// 			return reduceToggleVisibility(state, action);
// 		case POST_EDIT:
// 			return reduceEdit(state, action);
// 		case POST_SHOW:
// 			return reduceToggleVisibility(state, action);
// 		default:
// 			return state;
// 	}
// };
